shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never;

// Сфера вытянута назад (+Z), персонаж летит вперёд (-Z).

uniform vec4 core_color : source_color = vec4(0.75, 1.0, 1.0, 1.0);
uniform vec4 edge_color : source_color = vec4(0.1, 0.45, 1.0, 1.0);
uniform sampler2D noise_tex : repeat_enable, filter_linear; // NoiseTexture2D, Seamless = true

uniform float tail_length : hint_range(0.0, 6.0) = 2.5;  // длина хвоста
uniform float tail_taper  : hint_range(0.0, 1.0) = 0.9;  // сужение хвоста
uniform float scroll_speed : hint_range(0.0, 10.0) = 3.0;
uniform float streak_density : hint_range(1.0, 30.0) = 8.0;
uniform float fresnel_power : hint_range(0.5, 8.0) = 2.0;
uniform float intensity : hint_range(0.0, 5.0) = 1.6;
uniform float wobble : hint_range(0.0, 0.3) = 0.05;
uniform float alpha_boost : hint_range(0.0, 1.0) = 1.0;    // плавное появление/исчезание буста

varying float v_tail;

void vertex() {
	// хвост — задняя половина сферы
	float t = clamp(VERTEX.z, 0.0, 1.0);
	v_tail = t;
	VERTEX.z += t * tail_length;
	VERTEX.xy *= 1.0 - tail_taper * smoothstep(0.0, 1.0, t);
	// лёгкое дрожание контура
	float n = texture(noise_tex, vec2(UV.x * 3.0, UV.y * 2.0 - TIME * 1.5)).r;
	VERTEX += NORMAL * (n - 0.5) * wobble;
}

void fragment() {
	// полосы, бегущие вдоль хвоста
	vec2 uv = vec2(UV.x * streak_density, UV.y * 1.5 - TIME * scroll_speed);
	float streaks = texture(noise_tex, uv).r;
	streaks = smoothstep(0.35, 0.85, streaks);

	// ярче в центре (лицом к камере), синее по краям
	float fres = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), fresnel_power);
	vec3 col = mix(core_color.rgb, edge_color.rgb, fres);

	// хвост: тоньше и прозрачнее, но больше полос
	float tail_fade = 1.0 - smoothstep(0.2, 1.0, v_tail);
	float body = mix(1.0, streaks, smoothstep(0.0, 0.6, v_tail));

	float a = (0.35 + 0.65 * (1.0 - fres)) * body * tail_fade;

	ALBEDO = col * intensity;
	ALPHA = clamp(a, 0.0, 1.0) * alpha_boost;
}
