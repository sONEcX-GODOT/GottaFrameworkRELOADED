shader_type spatial;
render_mode unshaded, blend_add, cull_back, depth_draw_never;

// Форма меша не меняется. Гладкая светящаяся оболочка:
// белый блик спереди, голубой обод, тонкие полосы вдоль полёта.
// flight_dir = направление полёта в ЛОКАЛЬНЫХ координатах меша.

uniform vec3 flight_dir = vec3(0.0, 0.0, -1.0);
uniform vec4 core_color : source_color = vec4(0.85, 1.0, 1.0, 1.0);
uniform vec4 mid_color  : source_color = vec4(0.25, 0.8, 1.0, 1.0);
uniform vec4 edge_color : source_color = vec4(0.05, 0.35, 1.0, 1.0);
uniform sampler2D noise_tex : repeat_enable, filter_linear; // NoiseTexture2D, Seamless

uniform float scroll_speed : hint_range(0.0, 10.0) = 2.0;
uniform float streak_density : hint_range(0.5, 20.0) = 3.0;
uniform float streak_strength : hint_range(0.0, 1.0) = 0.5;
uniform float fresnel_power : hint_range(0.5, 8.0) = 1.5;
uniform float intensity : hint_range(0.0, 5.0) = 1.3;
uniform float front_glow : hint_range(0.0, 2.0) = 1.0;
uniform float alpha_boost : hint_range(0.0, 1.0) = 1.0;

varying vec3 v_pos;

void vertex() {
	v_pos = VERTEX;
}

void fragment() {
	vec3 d = normalize(flight_dir);
	vec3 up = abs(d.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
	vec3 t = normalize(cross(up, d));
	vec3 b = cross(d, t);

	float ndv = clamp(dot(normalize(NORMAL), normalize(VIEW)), 0.0, 1.0);
	float rim = pow(1.0 - ndv, fresnel_power);

	// -1 сзади ... +1 спереди
	float along = dot(normalize(v_pos), d);
	float front = smoothstep(-0.3, 1.0, along);

	// полосы: сечение сферы + медленный сдвиг по оси
	vec3 perp = v_pos - d * dot(v_pos, d);
	vec2 cs = vec2(dot(perp, t), dot(perp, b)) * streak_density;
	float flow = dot(v_pos, d) * 0.15 - TIME * scroll_speed * 0.2;
	float n1 = texture(noise_tex, cs + vec2(flow, 0.0)).r;
	float n2 = texture(noise_tex, cs * 1.7 + vec2(0.0, flow * 1.6)).r;
	float streaks = smoothstep(0.35, 0.8, n1 * 0.6 + n2 * 0.4);

	// цвет: белый спереди -> циан -> синий по краям и сзади
	vec3 col = mix(edge_color.rgb, mid_color.rgb, clamp(1.0 - rim + front * 0.5, 0.0, 1.0));
	col = mix(col, core_color.rgb, front * front);

	float a = rim * 0.8
		+ front * front_glow * (0.35 + 0.4 * (1.0 - rim))
		+ streaks * streak_strength * (0.25 + 0.75 * rim) * (1.0 - front * 0.5)
		+ 0.06;

	ALBEDO = col * intensity;
	ALPHA = clamp(a, 0.0, 1.0) * alpha_boost;
}
