shader_type canvas_item;

// Оставляем обычный sampler2D, так как вы успешно создали в нем AtlasTexture
uniform sampler2D over_texture : hint_default_transparent;

void fragment() {
    // 1. Получаем цвет текущего пикселя прогресс-бара
    vec4 base_color = texture(TEXTURE, UV);
    
    // 2. Автоматически извлекаем координаты региона из самого ресурса AtlasTexture
    // Свойство src_rect.xy — это позиция, src_rect.zw — это размер региона
    vec2 corrected_uv = src_rect.xy + (UV * src_rect.zw);
    
    // 3. Читаем пиксель обложки по правильным координатам
    vec4 over_sample = texture(over_texture, corrected_uv);
    
    // 4. Инвертированное маскирование (видно только в прозрачных местах)
    base_color.a *= (1.0 - over_sample.a);
    
    COLOR = base_color;
}
