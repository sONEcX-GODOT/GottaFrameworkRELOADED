shader_type sky;

group_uniforms Sky_Colors;
uniform vec3 zenith_color : source_color = vec3(0.015, 0.035, 0.11);
uniform vec3 horizon_color : source_color = vec3(0.06, 0.16, 0.36);
uniform vec3 glow_horizon_color : source_color = vec3(0.12, 0.32, 0.55);
uniform float horizon_falloff : hint_range(1.0, 10.0) = 3.5;

group_uniforms Moon;
uniform vec3 moon_color : source_color = vec3(0.95, 0.98, 1.0);
uniform vec3 moon_halo_color : source_color = vec3(0.25, 0.55, 0.95);
uniform float moon_size : hint_range(0.01, 0.2) = 0.055;
uniform float moon_halo_intensity : hint_range(0.0, 2.0) = 0.85;
uniform float moon_halo_falloff : hint_range(1.0, 20.0) = 6.0;

group_uniforms Stars_And_Nebula;
uniform float star_density : hint_range(20.0, 150.0) = 75.0;
uniform float star_brightness : hint_range(0.0, 5.0) = 2.5;
uniform float twinkle_speed : hint_range(0.0, 10.0) = 2.5;
uniform vec3 nebula_color : source_color = vec3(0.12, 0.22, 0.52);
uniform float nebula_intensity : hint_range(0.0, 2.0) = 0.55;

group_uniforms Clouds;
uniform vec3 cloud_color : source_color = vec3(0.08, 0.15, 0.30);
uniform vec3 cloud_rim_color : source_color = vec3(0.35, 0.65, 1.0);
uniform float cloud_speed : hint_range(0.0, 0.1) = 0.008;
uniform float cloud_coverage : hint_range(0.0, 1.0) = 0.45;

// Быстрый 2D хеш (вместо тяжелого 3D)
vec2 hash22(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.xx + p3.yz) * p3.zy);
}

float hash21(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

// Простой 2D Value Noise (1 октава)
float noise2d(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// Сверхбыстрые звезды без циклов (1 проверка на пиксель вместо 27)
vec3 fast_stars(vec2 uv, float scale, float time) {
    vec2 p = uv * scale;
    vec2 id = floor(p);
    vec2 f = fract(p) - 0.5;
    vec2 rnd = hash22(id) - 0.5;
    
    // Отбрасываем 75% ячеек сразу
    if (rnd.x > -0.25) return vec3(0.0);
    
    float d = length(f - rnd * 0.6);
    float star = smoothstep(0.12, 0.01, d);
    float twinkle = 0.65 + 0.35 * sin(time * twinkle_speed + rnd.y * 50.0);
    vec3 tint = mix(vec3(0.75, 0.88, 1.0), vec3(1.0, 0.95, 0.85), fract(rnd.y * 10.0));
    
    return tint * (star * star) * twinkle;
}

void sky() {
    vec3 dir = normalize(EYEDIR);
    float up = max(dir.y, 0.0);

    // 1. Градиент неба
    float horizon_mask = pow(1.0 - up, horizon_falloff);
    vec3 col = mix(zenith_color, horizon_color, horizon_mask);
    float horizon_line = 1.0 - abs(dir.y);
    col += glow_horizon_color * (horizon_line * horizon_line * horizon_line * horizon_line) * 0.45;

    // Сферическая проекция для звезд и туманности (работает без швов вверху)
    vec2 sky_uv = dir.xz / (up + 0.35);

    // 2. Легкая туманность (всего 2 вызова шума вместо 10)
    if (up > 0.01) {
        float band = 1.0 - abs(dot(dir, normalize(vec3(0.4, 0.6, -0.5))));
        band = max(band, 0.0);
        band *= band;
        
        float n = noise2d(sky_uv * 2.2) * 0.65 + noise2d(sky_uv * 4.8 + vec2(3.1)) * 0.35;
        col += nebula_color * smoothstep(0.42, 0.85, n) * band * nebula_intensity * smoothstep(0.0, 0.25, up);

        // 3. Звезды (без циклов)
        float star_fade = smoothstep(0.02, 0.2, up);
        col += fast_stars(sky_uv, star_density * 0.35, TIME) * star_brightness * star_fade;
    }

    // 4. Луна и ореол
    vec3 moon_dir = normalize(LIGHT0_DIRECTION);
    float moon_dot = max(dot(dir, moon_dir), 0.0);
    
    // Ореол
    col += moon_halo_color * pow(moon_dot, moon_halo_falloff) * moon_halo_intensity;

    // Диск луны (считаем через dot, без тяжелого acos)
    float moon_cos = cos(moon_size);
    if (moon_dot > moon_cos) {
        float edge = smoothstep(moon_cos, mix(moon_cos, 1.0, 0.15), moon_dot);
        vec2 moon_uv = (dir.xy - moon_dir.xy) / moon_size;
        float crater = noise2d(moon_uv * 4.5);
        vec3 surface = mix(moon_color * 0.82, moon_color, smoothstep(0.3, 0.75, crater));
        col = mix(col, surface * 1.25, edge);
    }

    // 5. Перистые облака (2 октавы 2D-шума)
    if (up > 0.01) {
        vec2 c_uv = dir.xz / (up + 0.18) + vec2(TIME * cloud_speed, TIME * cloud_speed * 0.3);
        float c_base = noise2d(c_uv * 1.4);
        float c_detail = noise2d(c_uv * 3.6 - vec2(TIME * cloud_speed * 1.2));
        float cloud_shape = c_base * 0.7 + c_detail * 0.3;
        
        float alpha = smoothstep(1.0 - cloud_coverage, 1.0, cloud_shape) * 1.4;
        alpha = clamp(alpha, 0.0, 0.9) * smoothstep(0.01, 0.22, up);

        // Лунная обводка облаков
        float silver_lining = (moon_dot * moon_dot * moon_dot * moon_dot) * (1.0 - alpha * 0.5);
        vec3 final_cloud = mix(cloud_color, cloud_rim_color, clamp(silver_lining * 1.4 + c_detail * 0.2, 0.0, 1.0));
        
        col = mix(col, final_cloud, alpha);
    }

    COLOR = col;
}
