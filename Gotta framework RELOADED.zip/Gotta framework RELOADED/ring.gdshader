shader_type spatial;

uniform vec3 gold_base : source_color = vec3(1.0, 0.72, 0.0);
uniform vec3 gold_light : source_color = vec3(1.0, 0.92, 0.25);
uniform vec3 gold_orange : source_color = vec3(0.85, 0.38, 0.02);
uniform vec3 gold_dark : source_color = vec3(0.45, 0.22, 0.0);

uniform float tube_offset = 0.0;      // сдвиг, если внутренняя сторона перепутана
uniform float inner_orange = 0.8;     // сила оранжевого внутри
uniform float top_highlight = 0.45;   // блик сверху
uniform float edge_darken = 0.5;      // затемнение по краям
uniform float emission_amount = 0.25;
uniform float metallic_amount = 0.85;
uniform float roughness_amount = 0.22;

void fragment() {
	// угол вокруг трубки: 1 = внешняя сторона, -1 = внутренняя
	float side = cos(UV.y * TAU + tube_offset);

	// базовый градиент: от золотого к светло-жёлтому наружу
	vec3 col = mix(gold_base, gold_light, smoothstep(-0.2, 1.0, side) * 0.6);

	// оранжевая внутренняя сторона
	float inner = smoothstep(0.2, -0.8, side);
	col = mix(col, gold_orange, inner * inner_orange);

	// мягкий блик сверху (в пространстве камеры)
	float top = clamp(NORMAL.y, 0.0, 1.0);
	col += gold_light * pow(top, 3.0) * top_highlight;

	// затемнение по контуру
	float fres = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), 3.0);
	col = mix(col, gold_dark, fres * edge_darken);

	ALBEDO = col;
	METALLIC = metallic_amount;
	ROUGHNESS = roughness_amount;
	EMISSION = col * emission_amount;
}