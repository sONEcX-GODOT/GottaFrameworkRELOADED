shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never;

uniform sampler2D boost_tex : source_color, filter_linear_mipmap, repeat_enable;
uniform vec4 boost_color : source_color = vec4(1.0, 1.0, 1.0, 1.0);
uniform float glow_power : hint_range(0.5, 5.0) = 1.5;
uniform float uv_spin_speed = 4.0; // Скорость вращения текстуры вокруг центра

void fragment() {
    // Сдвигаем центр координат в середину текстуры (0.5, 0.5)
    vec2 centered_uv = UV - vec2(0.5);
    
    float angle = TIME * uv_spin_speed;
    float s = sin(angle);
    float c = cos(angle);
    
    // Поворачиваем UV по кругу и возвращаем обратно
    vec2 rotated_uv = mat2(vec2(c, -s), vec2(s, c)) * centered_uv + vec2(0.5);
    
    vec4 tex = texture(boost_tex, rotated_uv);
    
    ALBEDO = tex.rgb * boost_color.rgb * COLOR.rgb * glow_power;
    ALPHA = tex.a * boost_color.a * COLOR.a;
}
