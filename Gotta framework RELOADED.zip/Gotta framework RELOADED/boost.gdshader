shader_type spatial;
render_mode blend_add, depth_draw_never, cull_disabled, unshaded;

// Настройки цвета и свечения
uniform vec4 boost_color : source_color = vec4(0.0, 0.5, 1.0, 1.0);
uniform float emission_strength : hint_range(0.0, 10.0) = 3.0;

// Настройки движения текстуры
uniform sampler2D noise_texture : repeat_enable;
uniform vec2 scroll_speed = vec2(0.0, -2.0);

// Настройки мягкости краев
uniform float fresnel_power : hint_range(0.1, 5.0) = 2.0;

void fragment() {
	// 1. Анимируем движение текстуры шума/полос по времени
	vec2 shifted_uv = UV + scroll_speed * TIME;
	float noise_value = texture(noise_texture, shifted_uv).r;
	
	// 2. Создаем эффект Френеля (плавное затухание на краях объекта)
	float fresnel = pow(1.0 - dot(NORMAL, VIEW), fresnel_power);
	
	// 3. Смешиваем шум и френель для получения финальной прозрачности (Альфы)
	float final_alpha = noise_value * fresnel;
	
	// Применяем цвета и свечение
	ALBEDO = boost_color.rgb;
	EMISSION = boost_color.rgb * emission_strength;
	ALPHA = final_alpha * boost_color.a;
}
