shader_type particles;

uniform float particle_count = 36.0;
uniform float start_radius = 0.65;
uniform float end_radius = 1.6;
uniform float min_scale = 0.45;
uniform float max_scale = 0.85;
uniform float height_offset = 0.08;

void start() {
	float step_angle = 6.2831853 / particle_count;
	float angle = float(INDEX) * step_angle;
	
	CUSTOM.x = angle;
	CUSTOM.y = 0.0;
	VELOCITY = vec3(0.0);
	
	vec3 start_pos = vec3(cos(angle) * start_radius, height_offset, sin(angle) * start_radius);
	
	// Задаем сразу и масштаб, и позицию через конструктор mat4
	TRANSFORM = mat4(
		vec4(min_scale, 0.0, 0.0, 0.0),
		vec4(0.0, min_scale, 0.0, 0.0),
		vec4(0.0, 0.0, min_scale, 0.0),
		vec4(start_pos, 1.0)
	);
	
	COLOR = vec4(1.0, 1.0, 1.0, 1.0);
}

void process() {
	CUSTOM.y += DELTA / LIFETIME;
	float life = clamp(CUSTOM.y, 0.0, 1.0);
	
	float ease = sin(life * 1.5707963);
	float current_radius = mix(start_radius, end_radius, ease);
	float s = mix(min_scale, max_scale, ease);
	
	float angle = CUSTOM.x;
	vec3 current_pos = vec3(cos(angle) * current_radius, height_offset, sin(angle) * current_radius);
	
	// Обновляем позицию и размер одной командой
	TRANSFORM = mat4(
		vec4(s, 0.0, 0.0, 0.0),
		vec4(0.0, s, 0.0, 0.0),
		vec4(0.0, 0.0, s, 0.0),
		vec4(current_pos, 1.0)
	);
	
	// Плавное исчезновение с самого начала движения до полного нуля в конце
	COLOR.a = 1.0 - smoothstep(0.0, 1.0, life);
}
