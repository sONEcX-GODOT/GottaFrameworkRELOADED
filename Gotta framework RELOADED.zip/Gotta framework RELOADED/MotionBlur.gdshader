shader_type canvas_item;

uniform sampler2D screen_texture : hint_screen_texture, repeat_disable, filter_linear_mipmap;

// Сила размытия по краям экрана (увеличивайте при бусте, например от 0.0 до 0.05)
uniform float blur_power : hint_range(0.0, 0.1) = 0.025;
// Радиус четкой зоны в центре (чтобы персонаж не мылился)
uniform float center_radius : hint_range(0.0, 1.0) = 0.25;
// Качество размытия (чем больше, тем плавнее полосы)
uniform int samples : hint_range(4, 16) = 10;

void fragment() {
	// Вектор от центра экрана к текущему пикселю
	vec2 dir = SCREEN_UV - vec2(0.5);
	float dist = length(dir);
	
	// Плавная маска: в центре 0 (четко), к краям усиливается
	float mask = smoothstep(center_radius, 0.8, dist);
	vec2 blur_vec = dir * blur_power * mask;
	
	vec3 color = vec3(0.0);
	for (int i = 0; i < samples; i++) {
		float scale = float(i) / float(samples - 1);
		vec2 sample_uv = clamp(SCREEN_UV - blur_vec * scale, vec2(0.001), vec2(0.999));
		color += texture(screen_texture, sample_uv).rgb;
	}
	
	COLOR = vec4(color / float(samples), 1.0);
}
