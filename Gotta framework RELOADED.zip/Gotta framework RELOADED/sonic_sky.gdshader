shader_type sky;
// Sonic Unleashed (Hedgehog Engine) style sky. Лёгкий, без текстур — для Android.

group_uniforms sky_colors;
uniform vec3 zenith_color : source_color = vec3(0.05, 0.25, 0.88);
uniform vec3 mid_color : source_color = vec3(0.16, 0.50, 0.98);
uniform vec3 horizon_color : source_color = vec3(0.45, 0.80, 1.0);
uniform vec3 haze_color : source_color = vec3(0.30, 0.62, 0.98);
uniform float saturation : hint_range(0.5, 2.0) = 1.25;
uniform float horizon_glow : hint_range(0.0, 1.0) = 0.06;
uniform float gradient_power : hint_range(0.3, 2.0) = 0.6;

group_uniforms sun;
uniform vec3 sun_color : source_color = vec3(1.0, 0.93, 0.72);
uniform float sun_size : hint_range(0.0005, 0.02) = 0.004;
uniform float sun_glow : hint_range(0.0, 3.0) = 1.2;

group_uniforms textures;
// Панорама неба (equirectangular, 2:1). Смешивается с градиентом.
uniform sampler2D sky_texture : source_color, filter_linear, repeat_enable;
uniform float sky_texture_mix : hint_range(0.0, 1.0) = 0.0;
uniform float sky_texture_yaw : hint_range(0.0, 6.2832) = 0.0;
uniform float sky_texture_brightness : hint_range(0.0, 3.0) = 1.0;
// Текстура облаков (бесшовная, канал R = плотность). Быстрее процедурного fbm.
uniform bool use_cloud_texture = false;
uniform sampler2D cloud_texture : filter_linear_mipmap, repeat_enable;

group_uniforms clouds;
uniform vec3 cloud_light : source_color = vec3(1.0, 1.0, 1.0);
uniform vec3 cloud_shadow : source_color = vec3(0.55, 0.66, 0.92);
uniform float cloud_coverage : hint_range(0.0, 1.0) = 0.56;
uniform float cloud_softness : hint_range(0.01, 0.6) = 0.14;
uniform float cloud_scale : hint_range(0.2, 5.0) = 0.9;
uniform float cloud_speed : hint_range(0.0, 0.1) = 0.008;

float hash(vec2 p) {
	p = fract(p * vec2(123.34, 456.21));
	p += dot(p, p + 45.32);
	return fract(p.x * p.y);
}

float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x),
			mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y);
}

// 4 октавы — компромисс качества и скорости на мобилках
float fbm(vec2 p) {
	float v = 0.0;
	float a = 0.5;
	for (int i = 0; i < 4; i++) {
		v += a * vnoise(p);
		p = p * 2.03 + vec2(17.1, 9.2);
		a *= 0.5;
	}
	return v;
}

vec3 saturate_col(vec3 c, float s) {
	float l = dot(c, vec3(0.299, 0.587, 0.114));
	return mix(vec3(l), c, s);
}

void sky() {
	vec3 dir = EYEDIR;
	float h = dir.y;

	// Градиент неба: яркий насыщенный синий -> светлый горизонт
	float gh = pow(clamp(h, 0.0, 1.0), gradient_power);
	vec3 col = mix(horizon_color, mid_color, smoothstep(0.0, 0.22, gh));
	col = mix(col, zenith_color, smoothstep(0.18, 0.85, gh));
	// Яркая светящаяся полоса у горизонта (как в Spagonia/Apotos)
	col += horizon_color * horizon_glow * pow(1.0 - clamp(abs(h), 0.0, 1.0), 10.0);
	// Ниже горизонта — голубая дымка (как далёкий океан/облака в Apotos)
	col = mix(col, haze_color, smoothstep(0.0, 0.25, -h));

	// Панорамная текстура неба
	if (sky_texture_mix > 0.0) {
		vec2 puv = vec2(atan(dir.x, dir.z) / TAU + 0.5 + sky_texture_yaw / TAU,
				acos(clamp(h, -1.0, 1.0)) / PI);
		// textureLod(…, 0.0) убирает шов от разрыва atan
		vec3 tex = textureLod(sky_texture, puv, 0.0).rgb * sky_texture_brightness;
		col = mix(col, tex, sky_texture_mix);
	}

	// Солнце
	vec3 L = vec3(0.0, 1.0, 0.0);
	if (LIGHT0_ENABLED) {
		L = LIGHT0_DIRECTION;
	}
	float sd = max(dot(dir, L), 0.0);
	float disc = smoothstep(1.0 - sun_size * 1.6, 1.0 - sun_size, sd);
	float glow = pow(sd, 6.0) * 0.25 + pow(sd, 48.0) * 0.5 + pow(sd, 400.0) * 1.0;
	col += sun_color * glow * sun_glow;
	col = mix(col, sun_color * 3.0, disc);

	// Мягкие стилизованные облака
	if (h > 0.0) {
		vec2 uv = dir.xz / (h + 0.18) * cloud_scale + vec2(TIME * cloud_speed, 0.0);
		float n;
		float n2;
		vec2 suv = uv + L.xz * 0.12;
		if (use_cloud_texture) {
			n = texture(cloud_texture, uv * 0.5).r;
			n2 = texture(cloud_texture, suv * 0.5).r;
		} else {
			n = fbm(uv);
			n2 = fbm(suv);
		}
		float c = smoothstep(cloud_coverage, cloud_coverage + cloud_softness, n);

		// Псевдо-освещение: сдвиг шума в сторону солнца
		float lit = clamp((n2 - n) * 5.0 + 0.55, 0.0, 1.0);
		vec3 ccol = mix(cloud_shadow, cloud_light, lit);
		ccol += sun_color * pow(sd, 5.0) * 0.45;   // серебристая кромка у солнца

		c *= smoothstep(0.0, 0.22, h);              // растворяются у горизонта
		col = mix(col, ccol, c);
	}

	COLOR = saturate_col(col, saturation);
}
