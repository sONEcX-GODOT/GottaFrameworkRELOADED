shader_type spatial;
render_mode cull_disabled;

uniform sampler2D albedo_tex : source_color, repeat_enable, filter_linear_mipmap;
uniform float layer : hint_range(0.0, 1.0) = 0.0;
uniform float fur_length = 0.02;
uniform float density = 400.0;
uniform float strand_width : hint_range(0.02, 1.0) = 0.15;
uniform float strand_height : hint_range(0.1, 1.0) = 0.8;
uniform vec3 gravity = vec3(0.0, -0.1, 0.0);
uniform float root_darkness : hint_range(0.0, 1.0) = 0.4;

float hash(vec2 p) {
	p = fract(p * vec2(123.34, 456.21));
	p += dot(p, p + 45.32);
	return fract(p.x * p.y);
}

void vertex() {
	VERTEX += NORMAL * fur_length * layer;
	VERTEX += gravity * fur_length * layer * layer;
}

void fragment() {
	vec2 cell_uv = UV * density;
	vec2 cell = floor(cell_uv);
	vec2 local = fract(cell_uv) - 0.5;
	// случайное смещение внутри ячейки, чтобы не было сетки
	local -= (vec2(hash(cell + 1.7), hash(cell + 3.1)) - 0.5) * 0.4;
	float rnd = hash(cell);

	float taper = 1.0 - layer * 0.7; // сужение к кончику
	float half_w = strand_width * 0.5 * taper;
	float half_h = strand_height * 0.5;
	float strand_len = mix(0.4, 1.0, rnd); // разная длина волосков
	bool outside = abs(local.x) > half_w || abs(local.y) > half_h;
	if (layer > 0.0 && (outside || layer > strand_len)) discard;

	ALBEDO = texture(albedo_tex, UV).rgb * mix(root_darkness, 1.0, layer);
	ROUGHNESS = 1.0;
}