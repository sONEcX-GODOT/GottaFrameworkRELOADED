extends GLTFDocumentExtension

pass
