shader_type spatial;

uniform sampler2D albedo_texture : source_color, filter_linear_mipmap;
uniform sampler2D fur_texture : source_color, filter_linear_mipmap, repeat_enable; // Ваша текстура шерсти

// Настройки шерсти
uniform float fur_tiling : hint_range(1.0, 50.0) = 15.0;   // Размер ворсинок
uniform float fur_strength : hint_range(0.0, 1.0) = 0.35;  // Насколько сильно видна фактура шерсти

// Настройки контурного света (Rim)
uniform vec4 rim_color : source_color = vec4(0.85, 0.93, 1.0, 1.0);
uniform float rim_power : hint_range(0.5, 8.0) = 2.5;
uniform float rim_intensity : hint_range(0.0, 3.0) = 0.85;

void fragment() {
	vec3 base_col = texture(albedo_texture, UV).rgb;
	
	// Накладываем фактуру шерсти поверх основного цвета
	vec3 fur = texture(fur_texture, UV * fur_tiling).rgb;
	// Смешиваем через мягкое умножение, чтобы мех не темнел слишком сильно
	vec3 fur_detail = mix(vec3(1.0), fur * 1.4, fur_strength);
	
	ALBEDO = base_col * fur_detail;
	
	// Чистый, плавный Rim по краям модели
	float rim = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), rim_power);
	EMISSION = rim_color.rgb * rim * rim_intensity;
}
