shader_type spatial;
render_mode unshaded, cull_disabled, blend_add, depth_draw_never;
uniform vec4 core_color : source_color = vec4(1.0, 1.0, 1.0, 1.0);
uniform vec4 edge_color : source_color = vec4(0.45, 0.25, 1.0, 1.0);
uniform float glow_intensity : hint_range(1.0, 10.0) = 3.5;
uniform float claw_count : hint_range(1.0, 6.0) = 4.0;
void fragment() {
	float length_fade = (1.0 - UV.x) * smoothstep(0.0, 0.08, UV.x);
	float wave = sin(UV.y * PI * claw_count);
	float stripes = pow(abs(wave), 3.0);
	float tip_boost = smoothstep(0.0, 0.7, UV.y);
	float alpha = stripes * length_fade * tip_boost;
	vec3 final_color = mix(edge_color.rgb, core_color.rgb, pow(stripes, 2.0));
	ALBEDO = final_color * glow_intensity;
	ALPHA = clamp(alpha, 0.0, 1.0);
}
