shader_type particles;

uniform float spread_angle : hint_range(0.0, 90.0) = 25.0; // Угол разлета конуса пыли
uniform float initial_speed_min = 3.0; // Минимальная скорость выброса
uniform float initial_speed_max = 6.0; // Максимальная скорость выброса
uniform float damping = 4.5; // Сопротивление воздуха (резкое торможение клубов пыли)
uniform float upward_buoyancy = 1.2; // Подъемная сила (пыль слегка всплывает)

uniform float start_scale = 0.2; // Начальный размер облачка
uniform float max_scale = 1.4; // Размер в середине жизни
uniform float end_scale = 0.0; // Конечный размер (сдувание в ноль)

uniform vec4 start_color : source_color = vec4(1.0, 0.96, 0.88, 1.0); // Цвет при появлении (яркий)
uniform vec4 end_color : source_color = vec4(0.6, 0.57, 0.55, 0.0); // Цвет в конце (серый и прозрачный)

// Простая функция псевдослучайных чисел для разброса частиц
float rand_from_seed(inout uint seed) {
	int k;
	int s = int(seed);
	if (s == 0) s = 305420679;
	k = s / 127773;
	s = 16807 * (s - k * 127773) - 2836 * k;
	if (s < 0) s += 2147483647;
	seed = uint(s);
	return float(seed % uint(65536)) / 65535.0;
}

uint hash(uint x) {
	x = ((x >> uint(16)) ^ x) * uint(73244475);
	x = ((x >> uint(16)) ^ x) * uint(73244475);
	x = (x >> uint(16)) ^ x;
	return x;
}

void start() {
	uint alt_seed = hash(NUMBER + uint(1) + RANDOM_SEED);
	
	// 1. Позиция спавна с учетом трансформации эмиттера
	TRANSFORM = EMISSION_TRANSFORM;
	
	// 2. Вычисляем случайное направление назад (по оси +Z эмиттера) с разбросом в конусе
	float angle_rad = radians(spread_angle);
	float theta = rand_from_seed(alt_seed) * 6.283185;
	float phi = rand_from_seed(alt_seed) * angle_rad;
	
	// Направление выброса: преимущественно назад (+Z) и немного вверх (+Y)
	vec3 dir = vec3(
		sin(phi) * cos(theta),
		abs(sin(phi) * sin(theta)) * 0.6 + 0.15, // Пыль не уходит под пол
		cos(phi)
	);
	dir = normalize(dir);
	
	// Переводим направление в мировые координаты эмиттера и задаем скорость
	float speed = mix(initial_speed_min, initial_speed_max, rand_from_seed(alt_seed));
	VELOCITY = (EMISSION_TRANSFORM * vec4(dir, 0.0)).xyz * speed;
	
	// 3. Сохраняем индивидуальную скорость вращения и прогресс жизни в CUSTOM
	CUSTOM.x = (rand_from_seed(alt_seed) - 0.5) * 6.0; // Скорость вращения
	CUSTOM.y = 0.0; // Нормализованное время жизни (от 0.0 до 1.0)
	
	// 4. Начальный цвет и масштаб
	COLOR = start_color;
	TRANSFORM[0].xyz *= start_scale;
	TRANSFORM[1].xyz *= start_scale;
	TRANSFORM[2].xyz *= start_scale;
}

void process() {
	// Обновляем прогресс жизни частицы от 0.0 до 1.0
	CUSTOM.y += DELTA / LIFETIME;
	float life = clamp(CUSTOM.y, 0.0, 1.0);
	
	// 1. Физика: торможение (Damping) и легкое всплытие
	VELOCITY -= VELOCITY * damping * DELTA;
	VELOCITY.y += upward_buoyancy * DELTA;
	TRANSFORM[3].xyz += VELOCITY * DELTA;
	
	// 2. Плавное затухание цвета и альфы (передается в меш через COLOR)
	COLOR = mix(start_color, end_color, smoothstep(0.2, 1.0, life));
	
	// 3. Кривая размера в стиле Sonic: резкий "поп" при появлении и сжатие в конце
	float current_scale;
	if (life < 0.2) {
		// Быстро раздувается в первые 20% жизни
		current_scale = mix(start_scale, max_scale, life / 0.2);
	} else {
		// Плавно сжимается в ноль к концу жизни
		current_scale = mix(max_scale, end_scale, (life - 0.2) / 0.8);
	}
	
	// Применяем масштаб (сбрасываем базис и умножаем на новый размер)
	TRANSFORM[0].xyz = normalize(TRANSFORM[0].xyz) * current_scale;
	TRANSFORM[1].xyz = normalize(TRANSFORM[1].xyz) * current_scale;
	TRANSFORM[2].xyz = normalize(TRANSFORM[2].xyz) * current_scale;
}
