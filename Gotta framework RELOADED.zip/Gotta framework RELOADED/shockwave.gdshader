shader_type canvas_item;

// Захват экрана под ColorRect в Godot 4
uniform sampler2D SCREEN_TEXTURE : hint_screen_texture, filter_linear_mipmap;

uniform vec2 center = vec2(0.5, 0.5);      // Центр волны на экране (от 0.0 до 1.0)
uniform float progress : hint_range(0.0, 1.0) = 0.0; // Прогресс волны (анимируется от 0 до 1)
uniform float force = 0.08;                // Сила искажения
uniform float thickness = 0.08;            // Толщина кольца волны

void fragment() {
	vec2 uv = SCREEN_UV;
	
	// Исправление пропорций экрана, чтобы волна была идеальным кругом, а не овалом
	vec2 aspect_uv = uv;
	float aspect = SCREEN_PIXEL_SIZE.y / SCREEN_PIXEL_SIZE.x;
	aspect_uv.x *= aspect;
	vec2 adjusted_center = center;
	adjusted_center.x *= aspect;
	
	float dist = distance(aspect_uv, adjusted_center);
	
	// Радиус волны растет от 0 до 1.2
	float wave_radius = progress * 1.2;
	
	// Проверяем, находится ли пиксель в пределах кольца волны
	if (dist <= wave_radius && dist >= wave_radius - thickness) {
		// Плавное затухание искажения к краям кольца
		float diff = dist - (wave_radius - thickness * 0.5);
		float pow_diff = 1.0 - abs(diff / (thickness * 0.5));
		
		// Направление смещения пикселя от центра
		vec2 dir = normalize(uv - center);
		uv += dir * pow_diff * force * (1.0 - progress);
	}
	
	// Выводим итоговый цвет с учетом искажения
	COLOR = texture(SCREEN_TEXTURE, uv);
}